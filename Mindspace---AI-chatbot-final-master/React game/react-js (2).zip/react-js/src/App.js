import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './components/Login';
import Register from './components/Register';
import Home from './components/Home';
import General from './components/General';
import Positive from './components/PositiveAffirmation';
import Meditation from './components/Meditation';
import Breathing from './components/Breathing';
import Park from './components/park';
import Games from './components/games';
import Error from './components/Error';
// import classes from './appClass.module.css';
import { Navbar, Nav, Container } from 'react-bootstrap';
import Image from 'react-bootstrap/Image';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

function App() {
  return (
    <Router>
    <div className="App"> 

    <Navbar bg="dark" variant="dark">
      <Navbar.Brand href="#home">MindSpace</Navbar.Brand>
      <Container style={{justifyContent: 'flex-end'}}>
        <Nav>
          <Nav.Link href="/sign-in">Login</Nav.Link>
          <Nav.Link href="/sign-up">Register</Nav.Link>
        </Nav>
      </Container>
    </Navbar>

      <div className="auth-wrapper">
        <div className="auth-inner">
          <Switch>
            <Route exact path='/' component={Login} />
            <Route path="/sign-in" component={Login} />
            <Route path="/sign-up" component={Register} />
            <Route path="/home" component={Home} exact />
            <Route path="/general" component={General} />
            <Route path="/positive" component={Positive} />
            <Route path="/meditation" component={Meditation} />
            <Route path="/breathing" component={Breathing} />
            <Route path="/games" component={Games} />
            <Route path="/park" component={Park} />
          </Switch>
        </div>
      </div>
    </div>
    </Router>
  );
}

export default App;
