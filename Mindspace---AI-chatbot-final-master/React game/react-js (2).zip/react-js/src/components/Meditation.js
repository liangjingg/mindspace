import React from 'react';
import './meditation.css';
import meditation1 from '../assets/Meditation1.mp4';
import meditation2 from '../assets/Meditation2.mp4';
import { NavLink } from 'react-router-dom';

const Meditation = () => {
    return (
        <html>
            <div className="meditation">
                <h1>Meditation by Goodful</h1>
                <h2>5-Minute Meditation You Can Do Anywhere</h2>
                    <video width="630" height="350" controls>
                        <source src={meditation1} type="video/mp4"/>
                        Your browser does not support the video tag.
                    </video>
                <br/><br/>
                <h2>10-Minute Meditation For Beginners</h2>
                <video width="630" height="350" controls>
                    <source src={meditation2} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            </div>
        </html>
    );
}

export default Meditation;