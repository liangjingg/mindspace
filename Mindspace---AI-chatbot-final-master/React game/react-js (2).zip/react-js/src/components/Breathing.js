import React from 'react';
import './meditation.css';
import breathing1 from '../assets/Breathing1.mp4';
import breathing2 from '../assets/Breathing2.mp4';
import { NavLink } from 'react-router-dom';

const Breathing = () => {
    return (
        <html>
            <div className="breathing">
                <h1>Breathing excercise by Goodful</h1>
                <h2>Calming Breathing Exercise</h2>
                <video width="630" height="350" controls>
                    <source src={breathing1} type="video/mp4" />
                    Your browser does not support the video tag.
                    </video>
                <br /><br />
                <h2>Breathing Techniques For Stress Relief</h2>
                <video width="630" height="350" controls>
                    <source src={breathing2} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            </div>
        </html>
    );
}

export default Breathing;