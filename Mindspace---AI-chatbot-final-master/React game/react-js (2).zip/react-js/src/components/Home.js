import React from 'react';
import botLogo from '../assets/bot.png';
import generalBtn from '../assets/general.png';
import downBtn from '../assets/down.png';
import overwhelmedBtn from '../assets/overwhelmed.png';
import stressedBtn from '../assets/stressed.png';
import './Home.css';
import { NavLink } from 'react-router-dom';

const home = () => {
    return (
        <div className="Home">
            <h1>how are you feeling today?</h1>
            <table>
                <tr>
                    <td><NavLink to="/general"><img src={generalBtn} className="ImgBtn" /></NavLink></td>
                    <td><img src={downBtn} className="ImgBtn" /></td>
                    <td><img src={overwhelmedBtn} className="ImgBtn" /></td>
                    <td><img src={stressedBtn} className="ImgBtn" /></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div>
        
    );
}

export default home;