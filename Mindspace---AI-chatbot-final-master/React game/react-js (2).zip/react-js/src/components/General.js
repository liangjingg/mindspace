import React from 'react';
import mediationBtn from '../assets/mediation.png';
import journalBtn from '../assets/journal.png';
import strengthBtn from '../assets/strength.png';
import affirmationBtn from '../assets/affirmation.png';
import gamesBtn from '../assets/games.png';
import walkBtn from '../assets/walk.png';
import breathingBtn from '../assets/breathing.png';
import chatBtn from '../assets/chatbot.png';
import './Home.css';
import { NavLink } from 'react-router-dom';

const General = () => {
    return (
        <div className="Home">
            <h1>choose your theraphy</h1>
            <table>
                <tr>
                    <td><NavLink to="/positive"><img src={affirmationBtn} className="ImgBtn" /></NavLink></td>
                    <td><NavLink to="/meditation"><img src={mediationBtn} className="ImgBtn" /></NavLink></td>
                    <td><NavLink to="/breathing"><img src={breathingBtn} className="ImgBtn" /></NavLink></td>
                    <td><NavLink to="/games"><img src={gamesBtn} className="ImgBtn" /></NavLink></td>
                </tr>
                <tr>
                    <td><NavLink to="/park"><img src={walkBtn} className="ImgBtn" /></NavLink></td>
                    <td><img src={chatBtn} className="ImgBtn" /></td>

                </tr>
            </table>
        </div>
    );
}

export default General;