import React from 'react';
import './positive.css';
import imptIcon from '../assets/impt.png';
import loveIcon from '../assets/love.png';
import { NavLink } from 'react-router-dom';

const PositiveAffirmation = () => {
	return (
		<div className="positive">
			<h1>positive affirmation</h1>
		<section className="container">
				<div className="spacing"/>
				<div className="positiveDesc">
                    <h2>positive wording</h2>
                    <p>Positive affirmations are very powerful because they release
                        you from negativity, fear, worry, and anxiety. When these
                        affirmations are repeated over and over again, they begin
                        to take charge of your thoughts, slowly changing your
                        pattern of thinking and ultimately changing your life.</p>
                </div>
                <table>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
					<tr>
                        <td>1. You are important and you matter!</td>
                        <td>2. You are so loved</td>
						<td>3. Your mistakes don't define you</td>
						<td>4. Your needs and wants are valid</td>
					</tr>
					<tr>
						<td>5. It is okay to ask for help</td>
						<td>6. Your boundaries are important and worth respect</td>
						<td>7. You attract beautiful things in life</td>
						<td>8. You are enough</td>

					</tr>
				</table>
			</section>
		</div>
    );
}

export default PositiveAffirmation;