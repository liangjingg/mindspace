import React, { Component, useState } from 'react';
import classes from './Login.module.css';
import { Form, InputGroup, Button, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Login = (props) => {
    
    const [validated, setValidated] = useState(false);
    
    const handleSubmit = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }
        setValidated(true);
    };
        
    return (
      <div className={classes.Container}>
        <Form className={classes.Form} noValidate validated={validated} onSubmit={handleSubmit}>
          <h3>Login</h3>
          {/* <Form.Row> */}
            <Form.Group style={{padding: '0'}} as={Col} controlId="validationCustom01">
              <Form.Label>Email Address</Form.Label>
              <Form.Control
                required
                type="text"
                placeholder="Enter Email"
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
            </Form.Group>
            <Form.Group style={{padding: '0'}} as={Col} controlId="validationCustom02">
              <Form.Label>Password</Form.Label>
              <Form.Control
                required
                type="password"
                placeholder="Password"
                defaultValue=""
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
          <Form.Group>
          </Form.Group>
            <Form.Check
              required
              label="Agree to terms and conditions"
              feedback="You must agree before submitting."
            />
          </Form.Group>
          <Button variant="danger" type="submit">Login</Button>
        </Form>
      </div>
        );
}

export default Login;